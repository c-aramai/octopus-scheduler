# OCTOPUS Scheduler v1.2.0

A macOS menu bar app that runs scheduled prompts through Claude Desktop, with Bridge connectivity for peer coordination and Slack notifications.

## Quick Start

1. **Copy the app** — Drag `OctopusScheduler.app` to your Applications folder
2. **First launch** — Right-click the app > Open (bypasses Gatekeeper on first run)
3. **Copy prompts** — Move the `prompts/` folder contents to `~/ARAMAI/prompts/scheduled/`
4. **Copy config** — Place `config/default-config.json` at `~/.octopus-scheduler/config.json`
5. **Edit config** — Update the Slack webhook URL and any other settings via the app's Settings window

## What It Does

- Runs `devrel-morning.md` at 9:00 AM weekdays (morning briefing to #devrel-ops)
- Runs `devrel-eod.md` at 5:00 PM weekdays (end-of-day report to #devrel-ops)
- Shows Bridge connection status (green/red/gray dot in menu bar)
- Lists online peers from the OCTOPUS Bridge
- Sends Slack notifications on prompt completion or failure

## Menu Bar

Click the 🐙 icon to see:
- Connection status to OCTOPUS Bridge
- Active and paused workflows with next fire times
- Online peers from the Bridge network
- Run Now (trigger any prompt immediately)
- Sync Now (reload config + refresh Bridge status)

## Settings

Open Settings (⌘,) to configure:
- **General** — Peer ID, domain, Bridge URL, launch at login
- **Schedules** — Manage prompt schedules and cron expressions
- **Notifications** — Slack webhook URL, channel, toggle notifications
- **About** — Version and ARAMAI branding

## Requirements

- macOS 13.0 (Ventura) or later
- Claude Desktop installed and running
- Accessibility permission granted to OctopusScheduler (for Claude automation)
